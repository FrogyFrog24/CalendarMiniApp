---
title: 'Flatlogic'
sidebarDepth: 2
---

### Flatlogic Templates

Thanks to Flatlogic for [mentioning us](https://flatlogic.com/blog/best-javascript-date-picker-libraries/) as one of the top Vue.js date pickers.

Support the development of V-Calendar by using one of the template links below to get a jump-start with your application.

<flatlogic-page />