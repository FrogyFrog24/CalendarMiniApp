<template>
  <div class="bg-gray-600 text-white px-2 py-3 text-center rounded">
    <p class="text font-bold mt-0 mb-0">
      This documentation applies for v1.0.0-beta.0
    </p>
    <p class="text-sm text-gray-200 my-0">
      <a href="../../../changelog/v1.0" class="underline text-gray-200"
        >See all breaking changes</a
      >, or
      <a
        href="https://vcalendar-legacy.netlify.com"
        class="underline text-gray-200"
        target="_blank"
        >reference previous documentation site</a
      >.
    </p>
  </div>
</template>
