<template>
  <div class="example">
    <v-calendar></v-calendar>
  </div>
</template>
