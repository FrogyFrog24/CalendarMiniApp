<template>
  <div class="example">
    <v-calendar is-expanded/>
  </div>
</template>