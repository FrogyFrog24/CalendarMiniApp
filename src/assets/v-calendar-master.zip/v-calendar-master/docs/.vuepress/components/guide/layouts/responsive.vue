<template>
  <div class="example">
    <v-calendar :columns="$screens({ lg: 2 }, 1)"/>
  </div>
</template>
