<template>
  <div class="example">
    <v-calendar trim-weeks />
  </div>
</template>
