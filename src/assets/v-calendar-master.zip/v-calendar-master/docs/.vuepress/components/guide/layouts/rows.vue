<template>
  <div class="example">
    <v-calendar :rows="2"/>
  </div>
</template>
