<template>
  <v-calendar is-dark/>
</template>

<script>
export default {
  data() {
    return {
      theme: {
        isDark: true,
      },
    };
  },
};
</script>

