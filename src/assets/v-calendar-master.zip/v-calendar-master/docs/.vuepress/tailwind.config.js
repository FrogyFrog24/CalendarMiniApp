module.exports = {
  variants: {
    extend: {
      textDecoration: ['hover'],
    },
  },
  theme: {
    extend: {
      width: {
        72: '18rem',
      },
    },
  },
};
