Visit the [docs site](https://vcalendar.io/changelog/v1.0.html) for all changelog info.
